-- Dept.xml
SELECT * FROM DEPT;



-- Emp.xml
SELECT * FROM EMP WHERE ENAME LIKE '%'||'A'||'%' AND JOB LIKE '%'||'S'||'%' AND DEPTNO=30;

