package com.tj.ch17.dao;

import java.util.List;

import com.tj.ch17.dto.Dept;

public interface DeptDao {
	public List<Dept> deptList();
	
}
